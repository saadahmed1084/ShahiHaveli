package application.views;

import application.database.MenuDAO;
import application.database.OrderDAO;
import application.database.ReservationDAO;
import application.models.*;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.util.*;

public class PlaceOrderView {
    private Stage primaryStage;
    private User currentUser;
    private String orderType;
    private Map<MenuItem, Integer> cart = new HashMap<>();
    private List<MenuItem> menuItems = new ArrayList<>();

    public PlaceOrderView(Stage primaryStage, User currentUser) {
        this.primaryStage = primaryStage;
        this.currentUser = currentUser;
    }

    public Scene createPlaceOrderScene() {
        VBox mainLayout = new VBox(20);
        mainLayout.setPadding(new Insets(20));
        mainLayout.setAlignment(Pos.TOP_CENTER);

        // Title with Mughal styling
        Label title = new Label("Place Your Order");
        title.setFont(new Font("Serif", 28));
        title.getStyleClass().add("title");
        title.setTextAlignment(TextAlignment.CENTER);

        // Order Type Selection
        Label orderTypeLabel = new Label("Select Order Type:");
        ToggleGroup orderTypeGroup = new ToggleGroup();
        RadioButton dineIn = new RadioButton("Dine-In");
        RadioButton takeaway = new RadioButton("Takeaway");
        RadioButton delivery = new RadioButton("Delivery");
        dineIn.setToggleGroup(orderTypeGroup);
        takeaway.setToggleGroup(orderTypeGroup);
        delivery.setToggleGroup(orderTypeGroup);

        HBox orderTypeBox = new HBox(15, dineIn, takeaway, delivery);
        orderTypeBox.setAlignment(Pos.CENTER);

        // Reservation ID for Dine-In
        Label reservationLabel = new Label("Reservation ID:");
        TextField reservationField = new TextField();
        reservationField.setPromptText("Enter your reservation ID");
        reservationField.setMaxWidth(200);
        HBox reservationBox = new HBox(10, reservationLabel, reservationField);
        reservationBox.setAlignment(Pos.CENTER);
        reservationBox.setVisible(false);

        dineIn.setOnAction(e -> {
            orderType = "Dine-In";
            reservationBox.setVisible(true);
        });
        takeaway.setOnAction(e -> {
            orderType = "Takeaway";
            reservationBox.setVisible(false);
        });
        delivery.setOnAction(e -> {
            orderType = "Delivery";
            reservationBox.setVisible(false);
        });

        // Cart Section (defined early so updateCart can reference it)
        VBox cartItems = new VBox(5);
        Label cartEmpty = new Label("Cart is empty");
        cartItems.getChildren().add(cartEmpty);

        TextArea specialRequirements = new TextArea();
        specialRequirements.setPromptText("Special requirements (optional)");
        specialRequirements.setPrefRowCount(3);
        specialRequirements.setMaxWidth(400);

        Label totalLabel = new Label("Total: Rs. 0.00");
        totalLabel.setFont(new Font("Serif", 16));
        totalLabel.setStyle("-fx-font-weight: bold;");

        Button confirmOrderButton = new Button("Confirm Order");
        confirmOrderButton.getStyleClass().add("login-button");
        confirmOrderButton.setDisable(true);

        // Update cart display - defined early so it can be used in menu items
        final Runnable[] updateCartRef = new Runnable[1];
        Runnable updateCart = () -> {
            cartItems.getChildren().clear();
            double total = 0;
            if (cart.isEmpty()) {
                cartItems.getChildren().add(new Label("Cart is empty"));
                confirmOrderButton.setDisable(true);
            } else {
                for (Map.Entry<MenuItem, Integer> entry : cart.entrySet()) {
                    MenuItem item = entry.getKey();
                    int qty = entry.getValue();
                    HBox cartItemBox = new HBox(10);
                    Label itemName = new Label(item.getName() + " x" + qty);
                    Label itemPrice = new Label("Rs. " + String.format("%.2f", item.getPrice() * qty));
                    Button removeBtn = new Button("Remove");
                    removeBtn.setOnAction(ev -> {
                        cart.remove(item);
                        updateCartRef[0].run();
                    });
                    cartItemBox.getChildren().addAll(itemName, itemPrice, removeBtn);
                    cartItems.getChildren().add(cartItemBox);
                    total += item.getPrice() * qty;
                }
                confirmOrderButton.setDisable(false);
            }
            totalLabel.setText("Total: Rs. " + String.format("%.2f", total));
        };
        updateCartRef[0] = updateCart;

        // Menu Display Area (Mughal Letter Format)
        ScrollPane menuScrollPane = new ScrollPane();
        VBox menuContainer = new VBox(15);
        menuContainer.setPadding(new Insets(20));

        // Menu Header (Letter-style)
        Label menuHeader = new Label("📜 Menu - Shahi Haveli 📜");
        menuHeader.setFont(new Font("Serif", 24));
        menuHeader.setTextAlignment(TextAlignment.CENTER);
        menuHeader.setStyle("-fx-text-fill: #d4af37; -fx-font-weight: bold;");

        Label menuGreeting = new Label("To His Majesty's Esteemed Guest,\n\n" +
                "We present to you our royal feast, prepared with the finest ingredients\n" +
                "and traditional recipes passed down through generations.\n");
        menuGreeting.setFont(new Font("Serif", 14));
        menuGreeting.setTextAlignment(TextAlignment.CENTER);
        menuGreeting.setWrapText(true);

        menuContainer.getChildren().addAll(menuHeader, menuGreeting);

        // Load menu items
        menuItems = MenuDAO.getAllMenuItems();
        if (menuItems.isEmpty()) {
            Label noItems = new Label("No menu items available. Please contact admin.");
            menuContainer.getChildren().add(noItems);
        } else {
            // Sort options
            Label sortLabel = new Label("Sort by:");
            ComboBox<String> sortCombo = new ComboBox<>(FXCollections.observableArrayList(
                    "Category", "Price (Low to High)", "Price (High to Low)"
            ));
            sortCombo.setValue("Category");
            HBox sortBox = new HBox(10, sortLabel, sortCombo);
            sortBox.setAlignment(Pos.CENTER);

            // Group by category
            Map<String, List<MenuItem>> categoryMap = new LinkedHashMap<>();
            for (MenuItem item : menuItems) {
                categoryMap.computeIfAbsent(item.getCategory(), k -> new ArrayList<>()).add(item);
            }

            // Display items by category (updateCart will be set later)
            for (Map.Entry<String, List<MenuItem>> entry : categoryMap.entrySet()) {
                Label categoryTitle = new Label("━━━ " + entry.getKey() + " ━━━");
                categoryTitle.setFont(new Font("Serif", 18));
                categoryTitle.setStyle("-fx-text-fill: #d4af37; -fx-font-weight: bold;");
                menuContainer.getChildren().add(categoryTitle);

                for (MenuItem item : entry.getValue()) {
                    HBox itemBox = createMenuItemBox(item, updateCartRef[0]);
                    menuContainer.getChildren().add(itemBox);
                }
            }

            sortCombo.setOnAction(e -> {
                String sortType = sortCombo.getValue();
                menuContainer.getChildren().clear();
                menuContainer.getChildren().addAll(menuHeader, menuGreeting, sortBox);

                List<MenuItem> sortedItems;
                if ("Price (Low to High)".equals(sortType)) {
                    sortedItems = MenuDAO.getMenuItemsSortedByPrice(true);
                } else if ("Price (High to Low)".equals(sortType)) {
                    sortedItems = MenuDAO.getMenuItemsSortedByPrice(false);
                } else {
                    sortedItems = MenuDAO.getAllMenuItems();
                }

                Map<String, List<MenuItem>> sortedCategoryMap = new LinkedHashMap<>();
                for (MenuItem item : sortedItems) {
                    sortedCategoryMap.computeIfAbsent(item.getCategory(), k -> new ArrayList<>()).add(item);
                }

                for (Map.Entry<String, List<MenuItem>> entry : sortedCategoryMap.entrySet()) {
                    Label catTitle = new Label("━━━ " + entry.getKey() + " ━━━");
                    catTitle.setFont(new Font("Serif", 18));
                    catTitle.setStyle("-fx-text-fill: #d4af37; -fx-font-weight: bold;");
                    menuContainer.getChildren().add(catTitle);

                    for (MenuItem item : entry.getValue()) {
                        HBox itemBox = createMenuItemBox(item, updateCartRef[0]);
                        menuContainer.getChildren().add(itemBox);
                    }
                }
            });

            menuContainer.getChildren().add(1, sortBox);
        }

        menuScrollPane.setContent(menuContainer);
        menuScrollPane.setFitToWidth(true);
        menuScrollPane.setPrefHeight(400);

        // Cart Section Box
        VBox cartBox = new VBox(10);
        cartBox.setPadding(new Insets(15));
        cartBox.setStyle("-fx-background-color: rgba(212, 175, 55, 0.1); -fx-border-color: #d4af37; -fx-border-width: 2;");
        Label cartTitle = new Label("Your Cart");
        cartTitle.setFont(new Font("Serif", 18));
        cartTitle.setStyle("-fx-text-fill: #d4af37; -fx-font-weight: bold;");

        cartBox.getChildren().addAll(cartTitle, cartItems, specialRequirements, totalLabel, confirmOrderButton);

        // Delivery fields
        VBox deliveryBox = new VBox(10);
        Label addressLabel = new Label("Delivery Address:");
        TextArea addressField = new TextArea();
        addressField.setPromptText("Enter your delivery address");
        addressField.setPrefRowCount(2);
        addressField.setMaxWidth(400);
        Label phoneLabel = new Label("Phone Number:");
        TextField phoneField = new TextField();
        phoneField.setPromptText("Enter your phone number");
        phoneField.setMaxWidth(400);
        deliveryBox.getChildren().addAll(addressLabel, addressField, phoneLabel, phoneField);
        deliveryBox.setVisible(false);

        delivery.setOnAction(e -> deliveryBox.setVisible(true));
        dineIn.setOnAction(e -> deliveryBox.setVisible(false));
        takeaway.setOnAction(e -> deliveryBox.setVisible(false));

        confirmOrderButton.setOnAction(e -> {
            if (cart.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Empty Cart");
                alert.setHeaderText(null);
                alert.setContentText("Please add items to your cart before confirming.");
                alert.showAndWait();
                return;
            }

            if (orderType == null) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Order Type Required");
                alert.setHeaderText(null);
                alert.setContentText("Please select an order type.");
                alert.showAndWait();
                return;
            }

            if ("Dine-In".equals(orderType)) {
                String resIdStr = reservationField.getText();
                if (resIdStr.isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Reservation Required");
                    alert.setHeaderText(null);
                    alert.setContentText("Please enter your reservation ID for dine-in orders.");
                    alert.showAndWait();
                    return;
                }
                try {
                    int resId = Integer.parseInt(resIdStr);
                    if (ReservationDAO.getReservationById(resId) == null) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Invalid Reservation");
                        alert.setHeaderText(null);
                        alert.setContentText("Reservation ID not found. Would you like to switch to takeaway?");
                        alert.showAndWait();
                        return;
                    }
                } catch (NumberFormatException ex) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Invalid Input");
                    alert.setHeaderText(null);
                    alert.setContentText("Please enter a valid reservation ID.");
                    alert.showAndWait();
                    return;
                }
            }

            if ("Delivery".equals(orderType)) {
                if (addressField.getText().isEmpty() || phoneField.getText().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Delivery Details Required");
                    alert.setHeaderText(null);
                    alert.setContentText("Please fill in delivery address and phone number.");
                    alert.showAndWait();
                    return;
                }
            }

            // Create order
            Order order = new Order();
            order.setUserId(currentUser.getUserId());
            if ("Dine-In".equals(orderType) && !reservationField.getText().isEmpty()) {
                order.setReservationId(Integer.parseInt(reservationField.getText()));
            }
            order.setOrderType(orderType);
            order.setOrderStatus("Receiving Order");
            order.setTotalAmount(Double.parseDouble(totalLabel.getText().replace("Total: Rs. ", "")));
            order.setPaymentStatus("pending");
            order.setSpecialRequirements(specialRequirements.getText());
            if ("Delivery".equals(orderType)) {
                order.setDeliveryAddress(addressField.getText());
                order.setDeliveryPhone(phoneField.getText());
            }
            if ("Takeaway".equals(orderType)) {
                order.setToken(OrderDAO.generateToken());
            }

            int orderId = OrderDAO.createOrder(order);
            if (orderId > 0) {
                // Add order items
                for (Map.Entry<MenuItem, Integer> entry : cart.entrySet()) {
                    OrderItem orderItem = new OrderItem();
                    orderItem.setOrderId(orderId);
                    orderItem.setItemId(entry.getKey().getItemId());
                    orderItem.setQuantity(entry.getValue());
                    orderItem.setPrice(entry.getKey().getPrice());
                    orderItem.setItemStatus("pending");
                    OrderDAO.addOrderItem(orderItem);
                }

                if ("Takeaway".equals(orderType)) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Order Confirmed");
                    alert.setHeaderText("Your Token: " + order.getToken());
                    alert.setContentText("Please keep this token for order pickup.");
                    alert.showAndWait();
                }

                // Navigate to payment
                PaymentView paymentView = new PaymentView(primaryStage, currentUser, orderId);
                primaryStage.setScene(paymentView.createPaymentScene());
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Failed to create order. Please try again.");
                alert.showAndWait();
            }
        });

        mainLayout.getChildren().addAll(title, orderTypeLabel, orderTypeBox, reservationBox, deliveryBox,
                menuScrollPane, cartBox);

        Scene scene = new Scene(mainLayout, 900, 800);
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());
        return scene;
    }

    private HBox createMenuItemBox(MenuItem item, Runnable updateCart) {
        HBox itemBox = new HBox(15);
        itemBox.setPadding(new Insets(10));
        itemBox.setStyle("-fx-background-color: rgba(43, 43, 43, 0.5); -fx-border-color: #d4af37; -fx-border-width: 1;");

        VBox itemInfo = new VBox(5);
        Label itemName = new Label(item.getName());
        itemName.setFont(new Font("Serif", 16));
        itemName.setStyle("-fx-text-fill: #d4af37; -fx-font-weight: bold;");
        Label itemDesc = new Label(item.getDescription());
        itemDesc.setFont(new Font("Serif", 12));
        itemDesc.setWrapText(true);
        Label itemPrice = new Label("Rs. " + String.format("%.2f", item.getPrice()));
        itemPrice.setFont(new Font("Serif", 14));
        itemPrice.setStyle("-fx-text-fill: #ffffff; -fx-font-weight: bold;");
        itemInfo.getChildren().addAll(itemName, itemDesc, itemPrice);

        HBox quantityBox = new HBox(10);
        Label qtyLabel = new Label("Qty:");
        Spinner<Integer> qtySpinner = new Spinner<>(0, 10, 0);
        qtySpinner.setPrefWidth(60);
        Button addToCartBtn = new Button("Add to Cart");
        addToCartBtn.getStyleClass().add("login-button");
        quantityBox.getChildren().addAll(qtyLabel, qtySpinner, addToCartBtn);
        quantityBox.setAlignment(Pos.CENTER_RIGHT);

        addToCartBtn.setOnAction(e -> {
            int qty = qtySpinner.getValue();
            if (qty > 0) {
                cart.put(item, cart.getOrDefault(item, 0) + qty);
                qtySpinner.getValueFactory().setValue(0);
                if (updateCart != null) updateCart.run();
            }
        });

        itemBox.getChildren().addAll(itemInfo, quantityBox);
        HBox.setHgrow(itemInfo, Priority.ALWAYS);
        return itemBox;
    }
}

