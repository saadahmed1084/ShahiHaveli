package application.views;

import application.database.UserDAO;
import application.models.User;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class RegisterView {
    private Stage primaryStage;

    public RegisterView(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public Scene createRegisterScene() {
        Label title = new Label("Register New Account");
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();
        Label phoneLabel = new Label("Phone:");
        TextField phoneField = new TextField();
        Label roleLabel = new Label("Role:");
        ComboBox<String> roleDropdown = new ComboBox<>();
        roleDropdown.getItems().addAll("Customer", "Employee");
        roleDropdown.setValue("Customer");

        usernameField.setMaxWidth(300);
        passwordField.setMaxWidth(300);
        emailField.setMaxWidth(300);
        phoneField.setMaxWidth(300);
        roleDropdown.setMaxWidth(150);

        Button registerButton = new Button("Register");
        Button backButton = new Button("Back to Login");
        Label messageLabel = new Label();

        VBox formLayout = new VBox(title,
                usernameLabel, usernameField,
                passwordLabel, passwordField,
                emailLabel, emailField,
                phoneLabel, phoneField,
                roleLabel, roleDropdown,
                registerButton, backButton,
                messageLabel);
        formLayout.setAlignment(Pos.CENTER);
        formLayout.setPadding(new Insets(30));
        formLayout.setSpacing(10);

        formLayout.getStyleClass().add("form-layout");
        title.getStyleClass().add("title");
        registerButton.getStyleClass().add("login-button");
        backButton.getStyleClass().add("register-button");
        messageLabel.getStyleClass().add("message-label");

        registerButton.setOnAction(e -> {
            String user = usernameField.getText();
            String pass = passwordField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
            String role = roleDropdown.getValue();

            if (user.isEmpty() || pass.isEmpty() || email.isEmpty() || phone.isEmpty() || role == null) {
                messageLabel.setText("Please fill all fields.");
                messageLabel.getStyleClass().add("error");
                return;
            }

            User newUser = new User();
            newUser.setUsername(user);
            newUser.setPassword(pass);
            newUser.setEmail(email);
            newUser.setPhone(phone);
            newUser.setRole(role);

            if (UserDAO.register(newUser)) {
                messageLabel.setText("Registration successful! Please login.");
                messageLabel.getStyleClass().add("success");
                backButton.fire();
            } else {
                messageLabel.setText("Registration failed. Username may already exist.");
                messageLabel.getStyleClass().add("error");
            }
        });

        backButton.setOnAction(e -> {
            LoginView loginView = new LoginView(primaryStage);
            primaryStage.setScene(loginView.createLoginScene());
        });

        Scene scene = new Scene(formLayout, 500, 650);
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());
        return scene;
    }
}



