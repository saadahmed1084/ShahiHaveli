package application.views;

import application.database.OrderDAO;
import application.models.Order;
import application.models.User;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.List;

public class ViewOrdersView {
    private Stage primaryStage;
    private User currentUser;

    public ViewOrdersView(Stage primaryStage, User currentUser) {
        this.primaryStage = primaryStage;
        this.currentUser = currentUser;
    }

    public Scene createViewOrdersScene() {
        VBox mainLayout = new VBox(20);
        mainLayout.setPadding(new Insets(30));
        mainLayout.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("My Orders");
        title.getStyleClass().add("title");

        List<Order> orders = OrderDAO.getOrdersByUserId(currentUser.getUserId());

        if (orders.isEmpty()) {
            Label noOrders = new Label("No orders found.");
            Button backButton = new Button("Back to Dashboard");
            backButton.setOnAction(e -> {
                CustomerDashboardView dashboard = new CustomerDashboardView(primaryStage, currentUser);
                primaryStage.setScene(dashboard.createCustomerDashboard());
            });
            mainLayout.getChildren().addAll(noOrders, backButton);
        } else {
            TableView<Order> ordersTable = new TableView<>();
            ordersTable.setItems(FXCollections.observableArrayList(orders));

            TableColumn<Order, Integer> orderIdCol = new TableColumn<>("Order ID");
            orderIdCol.setCellValueFactory(new PropertyValueFactory<>("orderId"));

            TableColumn<Order, String> typeCol = new TableColumn<>("Type");
            typeCol.setCellValueFactory(new PropertyValueFactory<>("orderType"));

            TableColumn<Order, String> statusCol = new TableColumn<>("Status");
            statusCol.setCellValueFactory(new PropertyValueFactory<>("orderStatus"));

            TableColumn<Order, Double> amountCol = new TableColumn<>("Amount");
            amountCol.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));

            TableColumn<Order, String> paymentCol = new TableColumn<>("Payment");
            paymentCol.setCellValueFactory(new PropertyValueFactory<>("paymentStatus"));

            ordersTable.getColumns().addAll(orderIdCol, typeCol, statusCol, amountCol, paymentCol);
            ordersTable.setPrefHeight(400);

            Button trackButton = new Button("Track Selected Order");
            trackButton.getStyleClass().add("login-button");
            trackButton.setOnAction(e -> {
                Order selected = ordersTable.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    TrackOrderView trackView = new TrackOrderView(primaryStage, currentUser);
                    primaryStage.setScene(trackView.createTrackOrderScene());
                }
            });

            mainLayout.getChildren().addAll(title, ordersTable, trackButton);
        }

        Button backButton = new Button("Back to Dashboard");
        backButton.getStyleClass().add("register-button");
        backButton.setOnAction(e -> {
            CustomerDashboardView dashboard = new CustomerDashboardView(primaryStage, currentUser);
            primaryStage.setScene(dashboard.createCustomerDashboard());
        });
        mainLayout.getChildren().add(backButton);

        Scene scene = new Scene(mainLayout, 800, 600);
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());
        return scene;
    }
}



