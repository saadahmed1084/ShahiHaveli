package application.views;

import application.database.DatabaseConnection;
import application.database.UserDAO;
import application.models.User;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LoginView {
    private Stage primaryStage;
    private User currentUser;

    public LoginView(Stage primaryStage) {
        this.primaryStage = primaryStage;
        DatabaseConnection.initializeDatabase();
    }

    public Scene createLoginScene() {
        // Logo
        Image logo = new Image(getClass().getResourceAsStream("/application/resources/ShahiHaveli_Logo.png"));
        ImageView logoView = new ImageView(logo);
        logoView.setFitWidth(120);
        logoView.setPreserveRatio(true);

        // Labels & Inputs
        Label title = new Label("Welcome to Shahi Haveli");
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();

        Label roleLabel = new Label("Role:");
        ComboBox<String> roleDropdown = new ComboBox<>();
        roleDropdown.getItems().addAll("Admin", "Employee", "Customer");
        roleDropdown.setPromptText("Select Role");

        usernameField.setMaxWidth(300);
        passwordField.setMaxWidth(300);
        roleDropdown.setMaxWidth(150);

        Button loginButton = new Button("Log in");
        Button registerButton = new Button("Register");
        Label messageLabel = new Label();

        // Layout
        VBox formLayout = new VBox(logoView,
                title,
                usernameLabel, usernameField,
                passwordLabel, passwordField,
                roleLabel, roleDropdown,
                loginButton, registerButton,
                messageLabel);
        formLayout.setAlignment(Pos.CENTER);
        formLayout.setPadding(new Insets(30));
        formLayout.setSpacing(10);

        // Style classes
        formLayout.getStyleClass().add("form-layout");
        title.getStyleClass().add("title");
        loginButton.getStyleClass().add("login-button");
        registerButton.getStyleClass().add("register-button");
        messageLabel.getStyleClass().add("message-label");

        // Login action
        loginButton.setOnAction(e -> {
            String user = usernameField.getText();
            String pass = passwordField.getText();
            String role = roleDropdown.getValue();

            if (user.isEmpty() || pass.isEmpty() || role == null) {
                messageLabel.setText("Please fill all fields.");
                messageLabel.getStyleClass().add("error");
                return;
            }

            User authenticatedUser = UserDAO.authenticate(user, pass, role);
            if (authenticatedUser != null) {
                currentUser = authenticatedUser;
                messageLabel.setText("Access Granted!");
                messageLabel.getStyleClass().add("success");
                
                // Navigate to appropriate dashboard
                if ("Admin".equals(role)) {
                    AdminDashboardView adminView = new AdminDashboardView(primaryStage, currentUser);
                    primaryStage.setScene(adminView.createAdminDashboard());
                } else if ("Customer".equals(role)) {
                    CustomerDashboardView customerView = new CustomerDashboardView(primaryStage, currentUser);
                    primaryStage.setScene(customerView.createCustomerDashboard());
                } else {
                    // Employee view (can be implemented later)
                    messageLabel.setText("Employee dashboard coming soon!");
                }
            } else {
                messageLabel.setText("Invalid credentials or role");
                messageLabel.getStyleClass().add("error");
            }
        });

        // Register action
        registerButton.setOnAction(e -> {
            RegisterView registerView = new RegisterView(primaryStage);
            primaryStage.setScene(registerView.createRegisterScene());
        });

        Scene scene = new Scene(formLayout, 500, 600);
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());

        return scene;
    }

    public User getCurrentUser() {
        return currentUser;
    }
}



