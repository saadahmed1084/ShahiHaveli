package application.views;

import application.models.User;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class AdminDashboardView {
    private Stage primaryStage;
    private User currentUser;

    public AdminDashboardView(Stage primaryStage, User currentUser) {
        this.primaryStage = primaryStage;
        this.currentUser = currentUser;
    }

    public Scene createAdminDashboard() {
        Label title = new Label("Shahi Haveli - Admin Dashboard");
        title.getStyleClass().add("title");

        Button manageMenuButton = new Button("Manage Menu Items");
        Button manageReservationsButton = new Button("Manage Reservations");
        Button viewReviewsButton = new Button("View Reviews");
        Button logoutButton = new Button("Logout");

        manageMenuButton.setPrefWidth(250);
        manageReservationsButton.setPrefWidth(250);
        viewReviewsButton.setPrefWidth(250);
        logoutButton.setPrefWidth(250);

        manageMenuButton.getStyleClass().add("login-button");
        manageReservationsButton.getStyleClass().add("login-button");
        viewReviewsButton.getStyleClass().add("login-button");
        logoutButton.getStyleClass().add("register-button");

        VBox layout = new VBox(20, title, manageMenuButton, manageReservationsButton, viewReviewsButton, logoutButton);
        layout.setAlignment(javafx.geometry.Pos.CENTER);
        layout.setPadding(new Insets(40));
        layout.getStyleClass().add("form-layout");

        manageMenuButton.setOnAction(e -> {
            ManageMenuView manageMenuView = new ManageMenuView(primaryStage, currentUser);
            primaryStage.setScene(manageMenuView.createManageMenuScene());
        });

        manageReservationsButton.setOnAction(e -> {
            ManageReservationsView manageReservationsView = new ManageReservationsView(primaryStage, currentUser);
            primaryStage.setScene(manageReservationsView.createManageReservationsScene());
        });

        viewReviewsButton.setOnAction(e -> {
            ViewReviewsView viewReviewsView = new ViewReviewsView(primaryStage, currentUser);
            primaryStage.setScene(viewReviewsView.createViewReviewsScene());
        });

        logoutButton.setOnAction(e -> {
            LoginView loginView = new LoginView(primaryStage);
            primaryStage.setScene(loginView.createLoginScene());
        });

        Scene scene = new Scene(layout, 600, 500);
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());
        return scene;
    }
}



