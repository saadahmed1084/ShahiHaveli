package application.views;

import application.models.User;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class CustomerDashboardView {
    private Stage primaryStage;
    private User currentUser;

    public CustomerDashboardView(Stage primaryStage, User currentUser) {
        this.primaryStage = primaryStage;
        this.currentUser = currentUser;
    }

    public Scene createCustomerDashboard() {
        Label title = new Label("Shahi Haveli - Customer Dashboard");
        title.getStyleClass().add("title");

        Button placeOrderButton = new Button("Place Order");
        Button trackOrderButton = new Button("Track Order Status");
        Button viewOrdersButton = new Button("View My Orders");
        Button logoutButton = new Button("Logout");

        placeOrderButton.setPrefWidth(250);
        trackOrderButton.setPrefWidth(250);
        viewOrdersButton.setPrefWidth(250);
        logoutButton.setPrefWidth(250);

        placeOrderButton.getStyleClass().add("login-button");
        trackOrderButton.getStyleClass().add("login-button");
        viewOrdersButton.getStyleClass().add("login-button");
        logoutButton.getStyleClass().add("register-button");

        VBox layout = new VBox(20, title, placeOrderButton, trackOrderButton, viewOrdersButton, logoutButton);
        layout.setAlignment(javafx.geometry.Pos.CENTER);
        layout.setPadding(new Insets(40));
        layout.getStyleClass().add("form-layout");

        placeOrderButton.setOnAction(e -> {
            PlaceOrderView placeOrderView = new PlaceOrderView(primaryStage, currentUser);
            primaryStage.setScene(placeOrderView.createPlaceOrderScene());
        });

        trackOrderButton.setOnAction(e -> {
            TrackOrderView trackOrderView = new TrackOrderView(primaryStage, currentUser);
            primaryStage.setScene(trackOrderView.createTrackOrderScene());
        });

        viewOrdersButton.setOnAction(e -> {
            ViewOrdersView viewOrdersView = new ViewOrdersView(primaryStage, currentUser);
            primaryStage.setScene(viewOrdersView.createViewOrdersScene());
        });

        logoutButton.setOnAction(e -> {
            LoginView loginView = new LoginView(primaryStage);
            primaryStage.setScene(loginView.createLoginScene());
        });

        Scene scene = new Scene(layout, 600, 500);
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());
        return scene;
    }
}



