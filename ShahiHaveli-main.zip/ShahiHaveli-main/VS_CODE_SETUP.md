# VS Code Setup Guide for Shahi Haveli Project

This guide will help you set up and run the Shahi Haveli Restaurant Management System in VS Code.

## Prerequisites

1. **Java Development Kit (JDK)**
   - Download JDK 11 or higher from [Oracle](https://www.oracle.com/java/technologies/downloads/) or [OpenJDK](https://adoptium.net/)
   - Verify installation:
     ```bash
     java -version
     javac -version
     ```

2. **MySQL Server**
   - Download and install MySQL from [MySQL Downloads](https://dev.mysql.com/downloads/mysql/)
   - Start MySQL service

3. **VS Code Extensions**
   - Install **Extension Pack for Java** (by Microsoft)
   - This includes:
     - Language Support for Java
     - Debugger for Java
     - Test Runner for Java
     - Maven for Java
     - Project Manager for Java

## Step-by-Step Setup

### Step 1: Open Project in VS Code

1. Open VS Code
2. Click **File** → **Open Folder**
3. Navigate to `ShahiHaveli-main` folder
4. Click **Select Folder**

### Step 2: Create Project Structure

VS Code should automatically detect Java files. If not, create a `.vscode` folder in the root with these files:

### Step 3: Download Dependencies

#### A. MySQL Connector/J

1. Download from: https://dev.mysql.com/downloads/connector/j/
2. Extract the JAR file (e.g., `mysql-connector-java-8.0.33.jar`)
3. Create a `lib` folder in your project root:
   ```
   ShahiHaveli-main/
   └── lib/
       └── mysql-connector-java-8.0.33.jar
   ```

#### B. JavaFX SDK (if using JDK 11+)

For JDK 11+, JavaFX is not included. You have two options:

**Option 1: Use JDK 8** (JavaFX included)
- Download JDK 8 from Oracle
- Set it as your Java runtime

**Option 2: Download JavaFX SDK** (for JDK 11+)
1. Download from: https://openjfx.io/
2. Extract to a folder (e.g., `C:\javafx-sdk-17`)
3. Note the path for later configuration

### Step 4: Configure VS Code Settings

Create `.vscode/settings.json`:

```json
{
    "java.project.sourcePaths": ["ShahiHaveli-main"],
    "java.project.outputPath": "bin",
    "java.project.referencedLibraries": [
        "lib/**/*.jar"
    ],
    "java.configuration.runtimes": [
        {
            "name": "JavaSE-1.8",
            "path": "C:\\Program Files\\Java\\jdk1.8.0_XXX",
            "default": true
        }
    ]
}
```

**For JavaFX (JDK 11+), add to settings.json:**
```json
{
    "java.jdt.ls.vmargs": "-Dfile.encoding=UTF-8"
}
```

### Step 5: Create Launch Configuration

Create `.vscode/launch.json`:

**For JDK 8 (JavaFX included):**
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "type": "java",
            "name": "Launch Main",
            "request": "launch",
            "mainClass": "application.Main",
            "projectName": "ShahiHaveli-main",
            "classPaths": [
                "${workspaceFolder}/lib/*"
            ]
        },
        {
            "type": "java",
            "name": "Initialize Database",
            "request": "launch",
            "mainClass": "application.database.InitializeMenuData",
            "projectName": "ShahiHaveli-main",
            "classPaths": [
                "${workspaceFolder}/lib/*"
            ]
        }
    ]
}
```

**For JDK 11+ (with JavaFX):**
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "type": "java",
            "name": "Launch Main",
            "request": "launch",
            "mainClass": "application.Main",
            "projectName": "ShahiHaveli-main",
            "classPaths": [
                "${workspaceFolder}/lib/*"
            ],
            "vmArgs": "--module-path \"C:/path/to/javafx-sdk-17/lib\" --add-modules javafx.controls,javafx.fxml"
        },
        {
            "type": "java",
            "name": "Initialize Database",
            "request": "launch",
            "mainClass": "application.database.InitializeMenuData",
            "projectName": "ShahiHaveli-main",
            "classPaths": [
                "${workspaceFolder}/lib/*"
            ]
        }
    ]
}
```

**Important:** Replace `C:/path/to/javafx-sdk-17/lib` with your actual JavaFX SDK path.

### Step 6: Setup Database

1. **Create MySQL Database:**
   ```sql
   CREATE DATABASE shahi_haveli;
   ```

2. **Update Database Credentials:**
   - Open `application/database/DatabaseConnection.java`
   - Update these lines:
     ```java
     private static final String DB_URL = "jdbc:mysql://localhost:3306/shahi_haveli";
     private static final String DB_USER = "root";
     private static final String DB_PASSWORD = "your_mysql_password";
     ```

### Step 7: Initialize Database and Menu

1. In VS Code, press `F5` or go to **Run and Debug** (Ctrl+Shift+D)
2. Select **"Initialize Database"** from the dropdown
3. Click the green play button or press `F5`
4. This will create all tables and populate menu items

### Step 8: Run the Application

1. In VS Code, press `F5` or go to **Run and Debug**
2. Select **"Launch Main"** from the dropdown
3. Click the green play button or press `F5`
4. The application window should open!

## Alternative: Using Terminal

If you prefer using the terminal:

### Compile and Run (JDK 8):

```bash
# Navigate to project root
cd ShahiHaveli-main

# Compile all Java files
javac -cp "lib/*" -d bin application/**/*.java

# Run InitializeMenuData first
java -cp "bin;lib/*" application.database.InitializeMenuData

# Run Main application
java -cp "bin;lib/*" application.Main
```

### Compile and Run (JDK 11+ with JavaFX):

```bash
# Navigate to project root
cd ShahiHaveli-main

# Set JavaFX path (adjust to your path)
set JAVA_FX_PATH=C:\javafx-sdk-17\lib

# Compile
javac --module-path %JAVA_FX_PATH% --add-modules javafx.controls -cp "lib/*" -d bin application/**/*.java

# Run InitializeMenuData
java -cp "bin;lib/*" application.database.InitializeMenuData

# Run Main application
java --module-path %JAVA_FX_PATH% --add-modules javafx.controls -cp "bin;lib/*" application.Main
```

## Troubleshooting

### Issue 1: "JavaFX runtime components are missing"

**Solution:**
- Make sure you're using JDK 8, OR
- Download JavaFX SDK and add `--module-path` and `--add-modules` to vmArgs in launch.json

### Issue 2: "ClassNotFoundException: com.mysql.cj.jdbc.Driver"

**Solution:**
- Make sure MySQL Connector JAR is in the `lib` folder
- Check that `classPaths` in launch.json includes `"${workspaceFolder}/lib/*"`

### Issue 3: "Database connection error"

**Solution:**
- Verify MySQL is running
- Check database credentials in `DatabaseConnection.java`
- Ensure database `shahi_haveli` exists

### Issue 4: "Resource not found" errors

**Solution:**
- Make sure `application.css` and `ShahiHaveli_Logo.png` are in `application/resources/` folder
- Check file paths in code use `/application/resources/...`

### Issue 5: VS Code doesn't recognize Java files

**Solution:**
1. Install "Extension Pack for Java"
2. Reload VS Code (Ctrl+Shift+P → "Reload Window")
3. Open a Java file to trigger Java Language Server

## Quick Start Checklist

- [ ] JDK installed and verified
- [ ] MySQL installed and running
- [ ] VS Code with Java extensions installed
- [ ] MySQL Connector JAR in `lib/` folder
- [ ] JavaFX SDK downloaded (if using JDK 11+)
- [ ] Database created (`shahi_haveli`)
- [ ] Database credentials updated
- [ ] `.vscode/launch.json` configured
- [ ] Database initialized (run InitializeMenuData)
- [ ] Application runs successfully!

## Default Login Credentials

After initializing the database, create an admin account:

**Option 1: Through Registration UI**
- Click "Register" on login screen
- Create account with role "Admin"

**Option 2: Direct SQL Insert**
```sql
INSERT INTO users (username, password, role, email, phone) 
VALUES ('admin', 'admin123', 'Admin', 'admin@shahihaveli.com', '1234567890');
```

Then login with:
- Username: `admin`
- Password: `admin123`
- Role: `Admin`

## Project Structure in VS Code

Your project should look like this:

```
ShahiHaveli-main/
├── .vscode/
│   ├── launch.json
│   └── settings.json
├── lib/
│   └── mysql-connector-java-8.0.33.jar
├── application/
│   ├── Main.java
│   ├── database/
│   ├── models/
│   ├── views/
│   ├── utils/
│   └── resources/
├── bin/ (created after compilation)
└── README.md
```

## Need Help?

If you encounter issues:
1. Check the error message in VS Code's "Problems" panel (Ctrl+Shift+M)
2. Check the "Output" panel for Java Language Server messages
3. Verify all prerequisites are installed
4. Ensure file paths are correct (Windows uses `\`, but Java uses `/`)

Happy coding! 🚀


