# Shahi Haveli Restaurant Management System

A comprehensive desktop application for managing a Pakistani restaurant, built with JavaFX and MySQL. The system features a beautiful Mughal-themed UI and implements all core restaurant management functionalities.

## Features

### Customer Features
1. **Place Order** - Choose from Dine-In, Takeaway, or Delivery options
2. **Track Order Status** - Real-time order tracking with status updates
3. **Accept/Reject Order** - Review and accept orders upon delivery
4. **Cancel Order** - Cancel orders with refund processing
5. **Submit Review** - Rate your dining experience
6. **View Orders** - View order history

### Admin Features
1. **Manage Menu Items** - Add, update, and delete menu items
2. **Manage Reservations** - Approve, decline, and manage reservations
3. **View Reviews** - View and filter customer reviews

### Payment Processing
- Multiple payment methods (Cash, Card, E-Wallet)
- Secure encrypted storage of payment data
- Promo code support
- Automatic refunds for cancellations

## Technology Stack

- **Java** - Core programming language
- **JavaFX** - UI framework
- **MySQL** - Database management
- **JDBC** - Database connectivity

## Prerequisites

1. **Java Development Kit (JDK)** - Version 11 or higher
2. **MySQL Server** - Version 5.7 or higher
3. **MySQL Connector/J** - JDBC driver for MySQL
4. **JavaFX SDK** - For JavaFX applications (included in JDK 11+)

## Setup Instructions

### 1. Database Setup

1. Install and start MySQL Server
2. Create a new database:
   ```sql
   CREATE DATABASE shahi_haveli;
   ```
3. Update database credentials in `DatabaseConnection.java`:
   ```java
   private static final String DB_URL = "jdbc:mysql://localhost:3306/shahi_haveli";
   private static final String DB_USER = "root";
   private static final String DB_PASSWORD = "your_password";
   ```

### 2. Add MySQL Connector

1. Download MySQL Connector/J from [MySQL Downloads](https://dev.mysql.com/downloads/connector/j/)
2. Add the JAR file to your project's classpath

### 3. Initialize Database and Menu

Run the `InitializeMenuData` class to create tables and populate sample menu items:
```bash
java application.database.InitializeMenuData
```

Or run it from your IDE:
- Right-click on `InitializeMenuData.java`
- Select "Run" or "Run as Java Application"

### 4. Create Admin Account

You can create an admin account through the registration interface, or insert directly into the database:
```sql
INSERT INTO users (username, password, role, email, phone) 
VALUES ('admin', 'admin123', 'Admin', 'admin@shahihaveli.com', '1234567890');
```

### 5. Run the Application

1. Compile all Java files
2. Run `Main.java`:
   ```bash
   java application.Main
   ```

Or from your IDE:
- Right-click on `Main.java`
- Select "Run" or "Run as Java Application"

## Project Structure

```
ShahiHaveli-main/
├── application/
│   ├── Main.java                    # Application entry point
│   ├── database/                    # Database layer
│   │   ├── DatabaseConnection.java  # DB connection management
│   │   ├── UserDAO.java            # User data access
│   │   ├── MenuDAO.java            # Menu data access
│   │   ├── OrderDAO.java            # Order data access
│   │   ├── ReservationDAO.java      # Reservation data access
│   │   ├── PaymentDAO.java         # Payment data access
│   │   ├── ReviewDAO.java          # Review data access
│   │   └── InitializeMenuData.java # Database initialization
│   ├── models/                      # Data models
│   │   ├── User.java
│   │   ├── MenuItem.java
│   │   ├── Order.java
│   │   ├── OrderItem.java
│   │   ├── Reservation.java
│   │   └── Review.java
│   ├── views/                       # UI views
│   │   ├── LoginView.java
│   │   ├── RegisterView.java
│   │   ├── CustomerDashboardView.java
│   │   ├── AdminDashboardView.java
│   │   ├── PlaceOrderView.java
│   │   ├── TrackOrderView.java
│   │   ├── PaymentView.java
│   │   ├── AcceptOrderView.java
│   │   ├── CancelOrderView.java
│   │   ├── ManageMenuView.java
│   │   ├── ManageReservationsView.java
│   │   ├── ViewReviewsView.java
│   │   ├── SubmitReviewView.java
│   │   └── ViewOrdersView.java
│   ├── utils/                       # Utilities
│   │   └── EncryptionUtil.java     # Payment data encryption
│   └── resources/                   # Resources
│       ├── application.css         # Stylesheet
│       └── ShahiHaveli_Logo.png    # Logo
└── README.md
```

## Use Cases Implemented

1. ✅ **Place Order** - Full implementation with Dine-In/Takeaway/Delivery
2. ✅ **Track Order Status** - Real-time status updates
3. ✅ **Accept Order** - Item-wise acceptance with redo/reject options
4. ✅ **Cancel Order** - Cancellation with refund processing
5. ✅ **Manage Menu Items** - CRUD operations for menu
6. ✅ **Manage Reservations** - Approve/decline reservations
7. ✅ **Process Payment** - Multiple payment methods with encryption
8. ✅ **Submit Review** - Rating system with feedback
9. ✅ **View Reviews** - Admin review management

## Default Credentials

After running `InitializeMenuData`, you can register new users or use:
- **Username**: admin
- **Password**: admin123 (or create your own)
- **Role**: Admin

## Menu Categories

The system includes a comprehensive Pakistani/Desi menu with:
- Biryani
- Karahi
- Breads
- Curries
- BBQ & Grilled
- Rice Dishes
- Desserts
- Beverages

## Security Features

- Password-based authentication
- Encrypted storage of payment card/wallet data
- Secure database connections
- Input validation

## Notes for VS Code

1. Install the **Extension Pack for Java** extension
2. Install **JavaFX** extension if needed
3. Configure your `launch.json` to include JavaFX modules:
   ```json
   {
     "type": "java",
     "request": "launch",
     "name": "Launch Main",
     "mainClass": "application.Main",
     "vmArgs": "--module-path /path/to/javafx/lib --add-modules javafx.controls,javafx.fxml"
   }
   ```

## Troubleshooting

1. **Database Connection Error**: Ensure MySQL is running and credentials are correct
2. **JavaFX Not Found**: Make sure JavaFX is properly configured in your classpath
3. **ClassNotFoundException**: Ensure MySQL Connector/J is in your classpath
4. **Resource Not Found**: Check that resources are in the correct path (`application/resources/`)

## Future Enhancements

- Kitchen staff interface for order management
- Real-time notifications
- Advanced reporting and analytics
- Online reservation system
- Mobile app integration

## License

This project is developed for educational purposes.

## Contact

For issues or questions, please contact the development team.

---

**Enjoy your Shahi Haveli experience! 🏰✨**



