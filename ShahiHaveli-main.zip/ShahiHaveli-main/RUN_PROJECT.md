# Complete Guide to Run Shahi Haveli Project

## ✅ Prerequisites Checklist
- [x] JDK installed
- [x] JavaFX installed
- [ ] MySQL Server installed and running
- [ ] MySQL Connector/J downloaded

## Step 1: Setup MySQL Database

1. **Start MySQL Server** (if not running)

2. **Create the database:**
   - Open MySQL Command Line or MySQL Workbench
   - Run:
   ```sql
   CREATE DATABASE shahi_haveli;
   ```

3. **Update database credentials:**
   - Open: `application/database/DatabaseConnection.java`
   - Find these lines (around line 10-12):
   ```java
   private static final String DB_URL = "jdbc:mysql://localhost:3306/shahi_haveli";
   private static final String DB_USER = "root";
   private static final String DB_PASSWORD = ""; // ← Change this to your MySQL password
   ```
   - Replace `""` with your MySQL password, e.g., `"mypassword123"`

## Step 2: Download MySQL Connector

1. **Download MySQL Connector/J:**
   - Go to: https://dev.mysql.com/downloads/connector/j/
   - Select "Platform Independent"
   - Download the ZIP file (e.g., `mysql-connector-j-8.0.33.zip`)

2. **Extract and place the JAR:**
   - Extract the ZIP file
   - Find `mysql-connector-j-8.0.33.jar` (or similar version)
   - Create a `lib` folder in your project root: `ShahiHaveli-main/lib/`
   - Copy the JAR file into `lib/` folder

   Your structure should look like:
   ```
   ShahiHaveli-main/
   ├── lib/
   │   └── mysql-connector-j-8.0.33.jar  ← Must be here!
   ├── application/
   └── ...
   ```

## Step 3: Configure VS Code for JavaFX

1. **Create `.vscode` folder** in project root (if it doesn't exist)

2. **Create `.vscode/launch.json`:**
   ```json
   {
       "version": "0.2.0",
       "configurations": [
           {
               "type": "java",
               "name": "Launch Main Application",
               "request": "launch",
               "mainClass": "application.Main",
               "projectName": "ShahiHaveli-main",
               "classPaths": [
                   "${workspaceFolder}/lib/*"
               ],
               "vmArgs": "--module-path \"C:/path/to/javafx-sdk-17/lib\" --add-modules javafx.controls,javafx.fxml"
           },
           {
               "type": "java",
               "name": "Initialize Database",
               "request": "launch",
               "mainClass": "application.database.InitializeMenuData",
               "projectName": "ShahiHaveli-main",
               "classPaths": [
                   "${workspaceFolder}/lib/*"
               ]
           }
       ]
   }
   ```

   **⚠️ IMPORTANT:** Replace `C:/path/to/javafx-sdk-17/lib` with your actual JavaFX SDK path!
   
   For example:
   - If JavaFX is at `C:\javafx-sdk-17\lib`, use: `"C:\\javafx-sdk-17\\lib"`
   - If JavaFX is at `D:\Java\javafx-sdk-17\lib`, use: `"D:\\Java\\javafx-sdk-17\\lib"`

3. **Create `.vscode/settings.json`:**
   ```json
   {
       "java.project.sourcePaths": ["ShahiHaveli-main"],
       "java.project.outputPath": "bin",
       "java.project.referencedLibraries": [
           "lib/**/*.jar"
       ]
   }
   ```

## Step 4: Initialize Database (Run This First!)

**Option A: Using VS Code (Easiest)**

1. Open `application/database/InitializeMenuData.java`
2. Click the **"Run"** button (▶️) that appears above `public static void main`
3. Or press `F5` and select "Initialize Database"
4. Wait for message: "Menu initialization complete! Added X items."

**Option B: Using Terminal**

Open VS Code terminal (`Ctrl + ~`) and run:

**Windows:**
```powershell
cd e:\ShahiHaveli-main\ShahiHaveli-main
javac -cp "lib/*" -d bin -sourcepath . application/database/*.java application/models/*.java
java -cp "bin;lib/*" application.database.InitializeMenuData
```

**Linux/Mac:**
```bash
cd ShahiHaveli-main
javac -cp "lib/*" -d bin -sourcepath . application/database/*.java application/models/*.java
java -cp "bin:lib/*" application.database.InitializeMenuData
```

## Step 5: Run the Application

**Option A: Using VS Code (Recommended)**

1. Open `Main.java` (in `ShahiHaveli-main` folder, not in `application` folder)
2. Click the **"Run"** button (▶️) above `public static void main`
3. Or press `F5` and select "Launch Main Application"
4. The login window should open! 🎉

**Option B: Using Terminal**

**Windows:**
```powershell
cd e:\ShahiHaveli-main\ShahiHaveli-main

# Compile everything
javac --module-path "C:/path/to/javafx-sdk-17/lib" --add-modules javafx.controls -cp "lib/*" -d bin -sourcepath . application/**/*.java

# Run the application
java --module-path "C:/path/to/javafx-sdk-17/lib" --add-modules javafx.controls -cp "bin;lib/*" application.Main
```

**Linux/Mac:**
```bash
cd ShahiHaveli-main

# Compile everything
javac --module-path "/path/to/javafx-sdk-17/lib" --add-modules javafx.controls -cp "lib/*" -d bin -sourcepath . application/**/*.java

# Run the application
java --module-path "/path/to/javafx-sdk-17/lib" --add-modules javafx.controls -cp "bin:lib/*" application.Main
```

**⚠️ Remember:** Replace the JavaFX path with your actual path!

## Step 6: Login to Application

1. **First time? Create an admin account:**
   - Click "Register" button
   - Fill in details
   - Select "Admin" as role
   - Click "Register"

2. **Or use default (if you added via SQL):**
   - Username: `admin`
   - Password: `admin123`
   - Role: `Admin`

## 🚨 Troubleshooting

### Error: "Could not find or load main class"
**Solution:** 
- Make sure you're running `application.Main`, not other classes
- Run from project root, not from subdirectories
- Check that compilation created `bin/application/Main.class`

### Error: "JavaFX runtime components are missing"
**Solution:**
- Check JavaFX path in `launch.json` is correct
- Make sure JavaFX SDK is properly extracted
- Verify `--module-path` points to the `lib` folder inside JavaFX SDK

### Error: "ClassNotFoundException: com.mysql.cj.jdbc.Driver"
**Solution:**
- Verify `lib/mysql-connector-j-*.jar` exists
- Check `classPaths` includes `"${workspaceFolder}/lib/*"`
- Rebuild the project

### Error: "Database connection error"
**Solution:**
- Verify MySQL is running
- Check database name is `shahi_haveli`
- Verify password in `DatabaseConnection.java` is correct
- Make sure you ran `InitializeMenuData` first

### Error: "Resource not found"
**Solution:**
- Check `application/resources/application.css` exists
- Check `application/resources/ShahiHaveli_Logo.png` exists
- Verify file paths in code

## 📋 Quick Reference Commands

**Find your JavaFX path:**
- Windows: Usually `C:\javafx-sdk-17\lib` or `C:\Program Files\Java\javafx-sdk-17\lib`
- Linux/Mac: Usually `/usr/lib/javafx-sdk-17/lib` or `~/javafx-sdk-17/lib`

**Verify JavaFX installation:**
```bash
# Check if JavaFX lib folder exists
dir C:\javafx-sdk-17\lib  # Windows
ls /path/to/javafx-sdk-17/lib  # Linux/Mac
```

**Verify MySQL Connector:**
```bash
# Check if JAR exists
dir lib\mysql-connector*.jar  # Windows
ls lib/mysql-connector*.jar  # Linux/Mac
```

## ✅ Final Checklist

Before running, verify:
- [ ] MySQL server is running
- [ ] Database `shahi_haveli` created
- [ ] Database password updated in `DatabaseConnection.java`
- [ ] MySQL Connector JAR in `lib/` folder
- [ ] JavaFX path configured in `launch.json`
- [ ] `InitializeMenuData` ran successfully
- [ ] All files compiled without errors

## 🎯 Success Indicators

When everything works, you should see:
1. ✅ Database initialization: "Menu initialization complete! Added 30+ items."
2. ✅ Application window opens with login screen
3. ✅ Can register/login successfully
4. ✅ Can navigate to different screens

---

**Need help?** Check the error message and refer to the Troubleshooting section above!


