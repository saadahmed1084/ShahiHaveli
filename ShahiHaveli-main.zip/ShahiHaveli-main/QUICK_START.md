# Quick Start Guide - VS Code

## ⚡ Fast Setup (5 Minutes)

### Step 1: Install Prerequisites
1. **Java JDK 8 or 11+** - [Download here](https://adoptium.net/)
2. **MySQL Server** - [Download here](https://dev.mysql.com/downloads/mysql/)
3. **VS Code Extensions:**
   - Install "Extension Pack for Java" (by Microsoft)

### Step 2: Setup Database
1. Open MySQL and create database:
   ```sql
   CREATE DATABASE shahi_haveli;
   ```

2. Edit `application/database/DatabaseConnection.java`:
   ```java
   private static final String DB_PASSWORD = "your_mysql_password";
   ```

### Step 3: Download Dependencies
1. Create `lib` folder in project root
2. Download MySQL Connector: https://dev.mysql.com/downloads/connector/j/
3. Place the JAR file in `lib/` folder (e.g., `lib/mysql-connector-java-8.0.33.jar`)

### Step 4: Run in VS Code

#### Method 1: Using VS Code Run Button (Easiest)

1. **First, initialize database:**
   - Open `application/database/InitializeMenuData.java`
   - Click the "Run" button above `public static void main`
   - Or press `Ctrl+F5`

2. **Then run the application:**
   - Open `Main.java` (in `ShahiHaveli-main` folder)
   - Click the "Run" button above `public static void main`
   - Or press `Ctrl+F5`

#### Method 2: Using Terminal (Recommended)

Open VS Code terminal (`Ctrl + ~`) and run:

**For Windows:**
```powershell
# Navigate to project root
cd e:\ShahiHaveli-main\ShahiHaveli-main

# Step 1: Initialize Database (run this first!)
javac -cp "lib/*" -d bin -sourcepath . application/database/InitializeMenuData.java application/database/*.java application/models/*.java
java -cp "bin;lib/*" application.database.InitializeMenuData

# Step 2: Compile the entire project
javac -cp "lib/*" -d bin -sourcepath . application/**/*.java

# Step 3: Run the application
java -cp "bin;lib/*" application.Main
```

**For Linux/Mac:**
```bash
# Navigate to project root
cd ShahiHaveli-main

# Step 1: Initialize Database (run this first!)
javac -cp "lib/*" -d bin -sourcepath . application/database/InitializeMenuData.java application/database/*.java application/models/*.java
java -cp "bin:lib/*" application.database.InitializeMenuData

# Step 2: Compile the entire project
javac -cp "lib/*" -d bin -sourcepath . application/**/*.java

# Step 3: Run the application
java -cp "bin:lib/*" application.Main
```

## 🚨 Common Errors & Solutions

### Error: "Could not find or load main class"
**Problem:** You're trying to run a class that doesn't have a main method, or running from wrong directory.

**Solution:** 
- Always run from project root (`ShahiHaveli-main`)
- Run `application.Main`, not individual model classes
- Use the full package path: `application.Main`

### Error: "Package does not exist"
**Problem:** Not compiling from the correct directory or missing classpath.

**Solution:**
- Make sure you're in the project root
- Include `lib/*` in classpath
- Compile all files together, not individually

### Error: "ClassNotFoundException: com.mysql.cj.jdbc.Driver"
**Problem:** MySQL Connector JAR not in classpath.

**Solution:**
- Make sure `lib/mysql-connector-java-*.jar` exists
- Include `lib/*` in your classpath when compiling and running

### Error: "JavaFX runtime components are missing"
**Problem:** Using JDK 11+ without JavaFX.

**Solution Options:**
1. **Use JDK 8** (JavaFX included) - Recommended
2. **Or add JavaFX to JDK 11+:** Download from https://openjfx.io/

## 📁 Correct Project Structure

```
ShahiHaveli-main/
├── lib/
│   └── mysql-connector-java-8.0.33.jar  ← Must have this!
├── application/
│   ├── Main.java                         ← Run this!
│   ├── database/
│   │   ├── InitializeMenuData.java      ← Run this first!
│   │   └── ...
│   ├── models/
│   │   └── MenuItem.java                ← Don't run this directly!
│   └── ...
└── bin/                                  ← Created after compilation
```

## ✅ Verification Checklist

Before running, make sure:
- [ ] MySQL is running
- [ ] Database `shahi_haveli` exists
- [ ] Database password updated in `DatabaseConnection.java`
- [ ] MySQL Connector JAR in `lib/` folder
- [ ] You're in project root directory
- [ ] Run `InitializeMenuData` first
- [ ] Then run `Main.java`

## 🎯 Quick Test

To verify everything works:

1. **Test Database Connection:**
   ```bash
   java -cp "bin;lib/*" application.database.InitializeMenuData
   ```
   Should see: "Menu initialization complete! Added X items."

2. **Test Application:**
   ```bash
   java -cp "bin;lib/*" application.Main
   ```
   Should open the login window!

## 💡 Pro Tips

1. **Use VS Code's built-in Java support:**
   - Just click the "Run" button above `main()` method
   - VS Code will auto-detect dependencies

2. **Create a batch file for Windows:**
   Create `run.bat`:
   ```batch
   @echo off
   echo Compiling...
   javac -cp "lib/*" -d bin -sourcepath . application/**/*.java
   echo Running...
   java -cp "bin;lib/*" application.Main
   pause
   ```

3. **Use tasks.json for automation:**
   See VS_CODE_SETUP.md for advanced configuration

---

**Remember:** Always run from project root, use full package names, and include `lib/*` in classpath! 🚀


